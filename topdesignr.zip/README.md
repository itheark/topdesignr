#Heroku Codeigniter bootstrap

For those struggling with deploying Codeigniter apps on Heroku, here is a bootstrap for you!

**composer.json**: add any additional dependencies here<br>
**.user.ini**: PHP settings

